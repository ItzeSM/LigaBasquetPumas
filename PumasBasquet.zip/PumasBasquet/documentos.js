document.addEventListener('DOMContentLoaded', function () {
    const documentosForm = document.getElementById('documentos-form');
    const mensajeExito = document.getElementById('documentos-enviados');
  
    documentosForm.addEventListener('submit', function (event) {
      if (!documentosForm.checkValidity()) {
        event.preventDefault();
        documentosForm.reportValidity();
        return;
      }
  
      event.preventDefault();
      mensajeExito.style.display = 'block';
      documentosForm.reset();
    });
  });
  
  function duplicarFormulario() {
    const original = document.querySelector('#documentos-form');
    const copia = original.cloneNode(true);
  
    // Quita el ID para que no haya duplicados
    copia.removeAttribute('id');
    copia.querySelectorAll('input').forEach(input => {
      const nombreOriginal = input.name;
      input.name = nombreOriginal + '-' + Date.now();
    });
  
    document.querySelector('.container').insertBefore(copia, document.querySelector('#documentos-enviados'));
  }
  