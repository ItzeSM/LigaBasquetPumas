document.addEventListener('DOMContentLoaded', function() {
    const addButton = document.getElementById('add-child-btn');
    const childrenContainer = document.getElementById('children-container');

    addButton.addEventListener('click', function() {
        const childCount = childrenContainer.children.length + 1;

        const newChildForm = document.createElement('div');
        newChildForm.classList.add('child-form');

        newChildForm.innerHTML = `
            <h3>Datos del Niño ${childCount}</h3>
            <label for="nombre-${childCount}">Nombre:</label>
            <input type="text" id="nombre-${childCount}" name="nombre" required>
            <!-- Agregar aquí el resto de los campos como el ejemplo anterior -->
        `;

        childrenContainer.appendChild(newChildForm);
    });
});
