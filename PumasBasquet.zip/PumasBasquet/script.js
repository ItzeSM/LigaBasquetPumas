function duplicarFormulario() {
  // Captura el formulario original
  const original = document.querySelector('.form-documentos');

  // Clona el formulario
  const copia = original.cloneNode(true);

  // Añade el formulario clonado al final del cuerpo del documento
  document.body.appendChild(copia);
}
